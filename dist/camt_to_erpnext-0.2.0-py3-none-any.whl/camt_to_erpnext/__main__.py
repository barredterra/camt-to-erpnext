from .main import app

app(prog_name="camt-to-erpnext")
